<!doctype html>
<html lang="fr">
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Chelsea Taekwondo | Site Web</title>

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('')); ?>" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">


        <link rel="stylesheet" href="<?php echo e(asset('assets/css/app')); ?>">

    </head>

    <body>

        <!-- Preloader -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>


        <div class="wrapper">



        </div>


    </body>

</html>
<?php /**PATH C:\laragon\www\ChelseaTkd\resources\views/layouts/app.blade.php ENDPATH**/ ?>