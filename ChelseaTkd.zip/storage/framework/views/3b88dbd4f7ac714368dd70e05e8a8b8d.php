<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-lg-12  m-auto">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="p-3">
                        CREATION D'UN NOUVEL ARTICLE
                    </h5>

                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="w-100">
                            <div class="row">
                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <div class="row">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4">
                                                    <li><?php echo e($error); ?></li>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <form id="" method="post" action="<?php echo e(route('article.store')); ?>">
                                    <?php echo csrf_field(); ?>


                                   <div class="row">
                                         <div class="col-lg-6">
                                            <div class="form-group">
                                                    <label for="nom">Titre</label>
                                                    <input type="text" class="form-control" placeholder="Entrer le titre" name="titre" value="<?php echo e(old('titre')); ?>">

                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label>Image de couverture</label>
                                                    <input type="file" accept="jpg,png" class="form-control"name="image_couverture" value="<?php echo e(old('image_couverture')); ?>">

                                                </div>
                                            </div>
                                   </div>
                                   <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="texte">Texte</label>
                                                <textarea class="ckeditor form-control" name="texte wysiwyg-editor "></textarea>
                                            </div>
                                        </div>


                                   </div>


                                   <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="images[]">Images / Videos</label>
                                                <div class="needsclick dropzone" id="document-dropzone">

                                                </div>
                                            </div>
                                        </div>
                                   </div>

                                   <div class="row">
                                        <div class="col-lg-6">
                                            <button class="btn btn-primary btn-block my-4" type="submit">Enregistrer</button>
                                        </div>
                                        <div class="col-lg-6">
                                            <a class="btn btn-success btn-block my-4" href="/">Retour</a>
                                        </div>
                                   </div>
                                </form>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        </div>



    </div>
    <!-- Page end  -->
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ChelseaTkd\resources\views/dashboard/articles/create.blade.php ENDPATH**/ ?>