<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-lg-10  m-auto">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="p-3">
                        IMPRESSION DE CARTE DE MEMBRE
                    </h5>
                    <form method="post" action="<?php echo e(route('print')); ?>">
                       <?php echo csrf_field(); ?>
                        <button class ="btn btn-primary" type="submit">Imprimer</button>
                    

                    
                    
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="w-100">
                            <table class="table table-striped" id="liste_pratiquant" style="width:100%">
                                <thead class="text-center">
                                    <tr>
                                        <th>Cocher</th>
                                        <th>#</th>
                                        <th>Numéro de passeport</th>
                                        <th>Nom & Prénoms</th>
                                        <th>Date de naissance</th>
                                        <th>Contact</th>
                                        <th>Grade Actuel</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <?php $i=0; ?>
                                    <!-- Boucle sur les données pour afficher les lignes -->
                                    <?php $__currentLoopData = $pratiquants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pratiquant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i++; ?>
                                        <tr>
                                            <td><input class="form-check-input" type="checkbox" name="pratiquants[]" value="<?php echo e($pratiquant->id); ?>"></td>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($pratiquant->num_passeport); ?></td>
                                            <td><?php echo e($pratiquant->nom); ?> <?php echo e($pratiquant->prenoms); ?></td>
                                            <td><?php echo e($pratiquant->dat_nais); ?></td>
                                            <td><?php echo e($pratiquant->contact); ?></td>
                                            <td><?php echo e($pratiquant->grade); ?></td>
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </form>
        </div>



    </div>
    <!-- Page end  -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#liste_pratiquant').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ChelseaTkd\resources\views/dashboard/pratiquants/print.blade.php ENDPATH**/ ?>