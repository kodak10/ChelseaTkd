<footer class="iq-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 text-left">
                <span class="mr-1">
                    Chelsea Taekwondo
                </span>
            </div>
            <div class="col-lg-6 text-right">
                <span class="mr-1">
                    Copyright
                    <script>document.write(new Date().getFullYear())</script>©
                    Tous droits reservés.
                </span>
            </div>
        </div>
    </div>
</footer>
