<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-lg-10  m-auto">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="p-3">
                        LISTE DES PRATIQUANTS
                    </h5>
                    <button class="btn btn-secondary">
                        <a href="/pratiquants/create" class="p-3">
                            NOUVEAU PRATIQUANT
                        </a>
                    </button>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="w-100">
                            <table class="table table-striped" id="liste_pratiquant" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Numéro de passeport</th>
                                        <th>Nom & Prénoms</th>
                                        <th>Date de naissance</th>
                                        <th>Contact</th>
                                        <th>Grade Actuel</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Boucle sur les données pour afficher les lignes -->
                                    <?php $__currentLoopData = $pratiquants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pratiquant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td></td>
                                            <td><?php echo e($pratiquant->num_passeport); ?></td>
                                            <td><?php echo e($pratiquant->nom); ?> <?php echo e($pratiquant->prenoms); ?></td>
                                            <td><?php echo e($pratiquant->dat_nais); ?></td>
                                            <td><?php echo e($pratiquant->contact); ?></td>
                                            <td><?php echo e($pratiquant->grade); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>


                            

                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>
    <!-- Page end  -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#liste_pratiquant').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ChelseaTkdWebsite\resources\views/dashboard/pratiquants/index.blade.php ENDPATH**/ ?>