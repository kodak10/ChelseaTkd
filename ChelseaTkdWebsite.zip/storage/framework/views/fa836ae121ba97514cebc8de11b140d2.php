<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-lg-10  m-auto">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="p-3">
                        CREATION DE NOUVEAU PRATIQUANT
                    </h5>

                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="w-100">
                            <div class="row">
                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <div class="row">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4">
                                                    <li><?php echo e($error); ?></li>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <form id="" method="post" action="<?php echo e(route('pratiquants.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                   <div class="row">
                                         <div class="col-lg-6">
                                            <div class="form-group">
                                                    <label for="nom">Nom</label>
                                                    <input type="text" class="form-control" placeholder="Entrez votre nom" name="nom" value="<?php echo e(old('nom')); ?>">
                                                    
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label for="prenoms">Prénoms</label>
                                                    <input type="text" class="form-control" placeholder="Entrez votre prénom" name="prenoms" value="<?php echo e(old('prenoms')); ?>">
                                                   
                                                </div>
                                            </div>
                                   </div>
                                   <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="dat_nais">Date de naissance</label>
                                                <input type="date" class="form-control" placeholder="" name="dat_nais" value="<?php echo e(old('dat_nais')); ?>">
                                               
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="lieu">Lieu</label>
                                                <input type="text" class="form-control" placeholder="Lieu de naissance" name="lieu" value="<?php echo e(old('lieu')); ?>">
                                               
                                            </div>
                                        </div>
                                   </div>

                                   <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="contact">Contact</label>
                                                <input type="text" class="form-control" placeholder="Ex : +225 0707572125" name="contact" value="<?php echo e(old('contact')); ?>">
                                               
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="profession">Profession</label>
                                                <input type="text" class="form-control" placeholder="Profession" name="profession" value="<?php echo e(old('profession')); ?>">
                                                
                                            </div>
                                        </div>
                                   </div>

                                   <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="num_passeport">Numéro de passeport</label>
                                                <input type="text" class="form-control" placeholder="Numéro de passeport" name="num_passeport" value="<?php echo e(old('num_passeport')); ?>">
                                               
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="grade">Grade Actuel</label>
                                                <select class="form-select" aria-label="" name="grade" value="<?php echo e(old('num_passeport')); ?>">
                                                    <option selected>Selectionner le grade</option>
                                                    <option value="1">Blanche</option>
                                                    <option value="1">1ère Jaune</option>
                                                    <option value="2">2ème Jaune</option>
                                                    <option value="1">1ère Verte</option>
                                                    <option value="2">2ème Verte</option>
                                                    <option value="1">1ère Bleu</option>
                                                    <option value="2">2ème Bleu</option>
                                                    <option value="1">1ère Rouge</option>
                                                    <option value="2">2ème Rouge</option>
                                                    <option value="1">1ère Dan</option>
                                                    <option value="1">2ère Dan</option>
                                                    <option value="1">3ère Dan</option>
                                                    <option value="1">4ère Dan</option>
                                                    <option value="1">5ère Dan</option>
                                                    <option value="1">6ère Dan</option>
                                                    <option value="1">7ère Dan</option>

                                                </select>
                                                   
                                            </div>
                                        </div>
                                   </div>

                                   <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="contact_urgence">Contact en cas d'urgence</label>
                                                <input type="text" class="form-control" placeholder="Contact en cas d'urgence" name="contact_urgence" value="<?php echo e(old('contact_urgence')); ?>">
                                                
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="photo">Photo</label>
                                                <input type="file" class="form-control" accept="jpg,png" placeholder="" name="photo">
                                                
                                            </div>
                                        </div>
                                   </div>

                                   <div class="row">
                                        <div class="col-lg-6">
                                            <button class="btn btn-primary btn-block my-4" type="submit">Inscrire</button>
                                        </div>
                                        <div class="col-lg-6">
                                            <button class="btn btn-success btn-block my-4">Retour</button>
                                        </div>
                                   </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ChelseaTkdWebsite\resources\views/dashboard/pratiquants/create.blade.php ENDPATH**/ ?>